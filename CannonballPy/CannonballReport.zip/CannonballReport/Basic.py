from math import *


def myRand():
    return double(double(rand()) / RAND_MAX)

# Return the sqare of a
def T(self, a):
    return sqrt(a)

# Return sign of x
sign = lambda x: (1, -1)[x >= 0]


# Angle conversions
def degToRad(self, x):
    return x * pi / 180

def radToDeg(self, x):
    return x * 180 / pi

# Degree Trig functions
def Sind(self, x): 
    return sin(degToRad(x))

def Cosd(self, x):
    return cos(degToRad(x))

def Tand(self, x):
    return tan(degToRad(x))

def aSind(self, x):
    return radToDeg(asin(x))

def aCosd(self, x):
    return radToDeg(acos(x))

def aTand(self, x):
    return radToDeg(atan(x))

def aTand2(self, x, y):
    return radToDeg(atan2(x,y))